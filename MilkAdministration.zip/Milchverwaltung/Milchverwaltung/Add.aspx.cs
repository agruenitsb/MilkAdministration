﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using Microsoft.AspNet.Identity;
using Microsoft.AspNet.Identity.Owin;
using Owin;
using System.Configuration;
using System.Data.SqlClient;
using System.Data;


namespace Milchverwaltung
{
    public partial class Add : Page
    {

        string getConnectionString()
        { 
            //Achtung - Hardcoded string
            return "Data Source=(LocalDB)\v11.0;AttachDbFilename=\"C:\\Users\\Andreas\\Documents\\Visual Studio 2013\\Projects\\Milchverwaltung\\Milchverwaltung\\App_Data\\DataBase.mdf\";Integrated Security=True"; 
        }

        protected void Page_Load(object sender, EventArgs e)
        {

        }

        protected void AddCoffee_Click(object sender, EventArgs e)
        {
            int portion = Convert.ToInt32(Kaffeemenge.Text);

            //var manager = Context.GetOwinContext().GetUserManager<ApplicationUserManager>();
            //var user = UserManager.FindById(User.Identity.GetUserId());

            string currentUserId = User.Identity.GetUserId();
            if (currentUserId == null) return;

            string username = HttpContext.Current.GetOwinContext()
    .GetUserManager<ApplicationUserManager>().FindById(currentUserId).UserName;

            SqlConnection conn = new SqlConnection(getConnectionString());
            string sql = "INSERT INTO konsum (user, timestamp, portion) VALUES "
                        + " (@user,@timestamp,@portion)";

            try
            {
                //Das funktioniert nicht!!!
                conn.Open();
                SqlCommand cmd = new SqlCommand(sql, conn);
                SqlParameter[] param = new SqlParameter[3];
                //param[0] = new SqlParameter("@id", SqlDbType.Int, 20);
                param[0] = new SqlParameter("@user", SqlDbType.VarChar, 50);
                param[1] = new SqlParameter("@timestamp", SqlDbType.VarChar, 50);
                param[2] = new SqlParameter("@portion", SqlDbType.VarChar, 50);


                param[0].Value = username;
                param[1].Value = DateTime.Now;
                param[2].Value = portion;
        

                for (int i = 0; i < param.Length; i++)
                {
                    cmd.Parameters.Add(param[i]);
                }

                cmd.CommandType = CommandType.Text;
                cmd.ExecuteNonQuery();
            }
            catch (System.Data.SqlClient.SqlException ex)
            {
                string msg = "Insert Error:";
                msg += ex.Message;
                throw new Exception(msg);
            }
            finally
            {
                conn.Close();
            }
            

        }

        protected void BuyMilk_Click(object sender, EventArgs e)
        {
            int i = Convert.ToInt32(Milchkauf.Text);
        }
    }
}