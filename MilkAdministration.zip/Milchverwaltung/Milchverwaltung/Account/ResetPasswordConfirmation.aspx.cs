﻿using System.Web.UI;

namespace Milchverwaltung.Account
{
    public partial class ResetPasswordConfirmation : Page
    {
    }
}