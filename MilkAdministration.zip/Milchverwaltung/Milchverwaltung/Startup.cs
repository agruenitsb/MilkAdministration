﻿using Microsoft.Owin;
using Owin;

[assembly: OwinStartupAttribute(typeof(Milchverwaltung.Startup))]
namespace Milchverwaltung
{
    public partial class Startup {
        public void Configuration(IAppBuilder app) {
            ConfigureAuth(app);
        }
    }
}
